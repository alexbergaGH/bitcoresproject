﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim bounds As Rectangle
        Dim screenshot As System.Drawing.Bitmap
        Dim graph As Graphics
        bounds = Screen.PrimaryScreen.Bounds
        screenshot = New System.Drawing.Bitmap(bounds.Width, bounds.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb)
        graph = Graphics.FromImage(screenshot)
        graph.CopyFromScreen(bounds.X, bounds.Y, 0, 0, bounds.Size, CopyPixelOperation.SourceCopy)
        PictureBox1.Image = screenshot
        PictureBox3.Image = screenshot
        PictureBox4.Image = screenshot
        PictureBox5.Image = screenshot
        PictureBox6.Image = screenshot
        PictureBox7.Image = screenshot
        PictureBox8.Image = screenshot
        PictureBox9.Image = screenshot
        PictureBox10.Image = screenshot
        PictureBox11.Image = screenshot
        PictureBox14.Image = screenshot
        PictureBox12.Left = MousePosition.Y
        PictureBox12.Top = MousePosition.X
        PictureBox15.Left = MousePosition.Y
        PictureBox15.Top = MousePosition.X


    End Sub

    Private Sub PictureBox14_Click(sender As Object, e As EventArgs) Handles PictureBox14.Click

    End Sub

    Private Sub PictureBox12_Click(sender As Object, e As EventArgs) Handles PictureBox12.Click

    End Sub

    Private Sub PictureBox13_Click(sender As Object, e As EventArgs) Handles PictureBox13.Click

    End Sub

    Private Sub PictureBox15_Click(sender As Object, e As EventArgs) Handles PictureBox15.Click

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub
End Class
