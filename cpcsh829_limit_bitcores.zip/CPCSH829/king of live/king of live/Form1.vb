﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim GTR As Icon
        GTR = (My.Resources.Webp_net_gifmaker)
        Me.Cursor = New Cursor(GTR.Handle)
    End Sub
End Class
