﻿Public Class Form1
    Dim X As New Random
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MsgBox(" start? ", MsgBoxStyle.YesNo, "ezgame")
        Timer1.Start()

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If DesktopLocation = New Point(X.Next(0, 400), X.Next(0, 400)) Then
            DesktopLocation = New Point(X.Next(0, 400), X.Next(0, 400))
        Else
            DesktopLocation = New Point(X.Next(0, 400), X.Next(0, 400))

        End If
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MsgBox("hi")
    End Sub

    Private Sub AxWindowsMediaPlayer1_Enter(sender As Object, e As EventArgs) Handles AxWindowsMediaPlayer1.Enter

    End Sub
End Class
