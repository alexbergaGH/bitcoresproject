﻿Public Class Form1

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim savefiledialog1 As New SaveFileDialog
        Try
            savefiledialog1.Title = "take a photo "
            savefiledialog1.FileName = "image for vnpri.png"
            savefiledialog1.Filter = "Bitmap |*.png"
            If savefiledialog1.ShowDialog() = DialogResult.OK Then
                PictureBox1.Image.Save(savefiledialog1.FileName, System.Drawing.Imaging.ImageFormat.Bmp)
            End If
        Catch ex As Exception
            'Do Nothing
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim bounds As Rectangle
        Dim screenshot As System.Drawing.Bitmap
        Dim graph As Graphics
        bounds = Screen.PrimaryScreen.Bounds
        screenshot = New System.Drawing.Bitmap(bounds.Width, bounds.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb)
        graph = Graphics.FromImage(screenshot)
        graph.CopyFromScreen(bounds.X, bounds.Y, 0, 0, bounds.Size, CopyPixelOperation.SourceCopy)
        PictureBox1.Image = screenshot
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MsgBox("my you tube:https://www.youtube.com/channel/UC_LTUdCAYW-ddIGpfUpmwOA ", MsgBoxStyle.Information, "")
    End Sub
End Class
