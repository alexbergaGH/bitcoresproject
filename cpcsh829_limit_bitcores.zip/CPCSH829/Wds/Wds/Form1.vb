﻿Public Class Form1

    Private Sub CloseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CloseToolStripMenuItem.Click
        End
    End Sub

    Private Sub RunToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RunToolStripMenuItem.Click
        ListBox1.Items.Clear()
        ListBox1.Items.AddRange(TextBox1.Lines)
        For i = 0 To ListBox1.Items.Count - 1
            Dim teststring As String = ListBox1.Items.Item(i)
            Dim testarray() As String = Split(teststring)
            Dim user As New Random

            If testarray(0) = "start.class" Then

            End If

            If testarray(0) = "class.write.d" Then
                MsgBox(testarray(1))
            End If
            If testarray(0) = "class.beep.c" Then
                Beep()
            End If
            If testarray(0) = "end.class" Then
                End
                If testarray(0) = "style.write" Then
                    MsgBox(testarray(1))
                End If
                If testarray(0) = "FSI" Then
                    MsgBox("copyright 2021 by vietnampress", MsgBoxStyle.Information, "hi")
                End If

            End If

        Next
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        MsgBox("SI = start", MsgBoxStyle.Information, "help")
        MsgBox("import.system.write = text", MsgBoxStyle.Information, "help")
        MsgBox("system.beep = write write x2", MsgBoxStyle.Information, "help")
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
