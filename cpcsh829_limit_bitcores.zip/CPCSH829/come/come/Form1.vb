﻿Public Class Form1

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs)

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub



    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub RunToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub CloseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CloseToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub RunToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles RunToolStripMenuItem.Click
        ListBox1.Items.Clear()
        ListBox1.Items.AddRange(TextBox1.Lines)
        For i = 0 To ListBox1.Items.Count - 1
        Next
        Dim teststring As String = ListBox1.Items.Item(10)
        Dim testarray() As String = Split(teststring)

        If testarray(0) = "console.pritf" Then
            MsgBox(testarray(1), , testarray(2))
        End If
        If testarray(0) = "title" Then
            Beep()
        End If
        If testarray(0) = "end.tab" Then
            End

        End If
    End Sub
End Class
