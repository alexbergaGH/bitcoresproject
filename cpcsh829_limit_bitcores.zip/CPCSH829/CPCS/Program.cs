﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CPCS
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor
                    = ConsoleColor.Green;

            Console.WriteLine("[]~applicationsearch",
                                    Console.ForegroundColor);

            Console.ForegroundColor
                = ConsoleColor.Gray;

            Console.WriteLine("application~?code",
                                    Console.ForegroundColor);
                     

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.WriteLine("43573374");
            Console.ResetColor();

           int optionsCount = 5;

int selected = 0;

bool done = false;

while (!done)
{
    for (int i = 0; i < optionsCount; i++)
    {
        if (selected == i)
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("> ");
        }
        else
        {
            Console.Write("  ");
        }
    }
}
