﻿Public Class Form1
    Dim X As Integer
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load 
        LinkLabel1.Text = "click here"
        LinkLabel1.Links.Add(6, 4, "www.mediafire.com/3284326gde")
    End Sub
    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal _
e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles _
LinkLabel1.LinkClicked
        System.Diagnostics.Process.Start(e.Link.LinkData.ToString())
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ProgressBar1.Increment(1)
        If ProgressBar1.Value = 1000 Then
            Timer1.Stop()
            MsgBox("No updates available", MsgBoxStyle.Critical, "update")
            MsgBox("error try again", MsgBoxStyle.Critical, "update")
        End If

    End Sub

    Private Sub ProgressBar1_Click(sender As Object, e As EventArgs) Handles ProgressBar1.Click

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        MsgBox("press  the button(ok) to continue", MsgBoxStyle.MsgBoxHelp, "mission note")
        MsgBox("Be careful with the ultimate mission error", MsgBoxStyle.Information, "mission note")
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Dim rnd As New Random
        For i = 5 To 20
            Dim pict As New PictureBox
            pict.BackColor = Color.Red
            pict.Height = 5
            pict.Width = 5
            pict.Location = New Point(rnd.Next(0, My.Computer.Screen.Bounds.Width),
                                      rnd.Next(0, My.Computer.Screen.Bounds.Height))
            Me.Controls.Add(pict)
            X += 1
            Label1.Text = X
        Next
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim rndpro As New Random
        MsgBox(rndpro.Next(0, 999999999), MsgBoxStyle.Information, "don't click")
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        Dim rnd As New Random
        For i = 5 To 20
            Dim pict As New PictureBox
            pict.BackColor = Color.Red
            pict.Height = 5
            pict.Width = 5
            pict.Location = New Point(rnd.Next(0, My.Computer.Screen.Bounds.Width),
                                      rnd.Next(0, My.Computer.Screen.Bounds.Height))
            Me.Controls.Add(pict)
            X += 1
            Label1.Text = X
        Next
    End Sub
    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Timer3.Start()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        MsgBox("goser?tipcontrol.bat")
    End Sub
End Class
